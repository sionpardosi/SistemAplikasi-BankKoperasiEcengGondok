<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Order;
use App\Models\Address;
use App\Models\OrderItem;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\SupplierRequest;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\PendingOrder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use App\Models\BankAccount;

class UserController extends Controller
{
    public function index()
    {
        return view("user.index");
    }

    public function account_orders()
    {
        // Ambil order yang sudah confirmed/dibayar
        $orders = Order::where('user_id', Auth::user()->id)->orderBy('created_at', 'DESC')->paginate(8);

        // Ambil pending orders yang belum expired
        $pendingOrders = PendingOrder::where('user_id', Auth::user()->id)
            ->where('status', 'pending_payment')
            ->where('expires_at', '>', now())
            ->orderBy('created_at', 'DESC')
            ->get();

        return view('user.orders', compact('orders', 'pendingOrders'));
    }

    public function account_order_details($order_id)
    {
        $order = Order::where('user_id', Auth::user()->id)->find($order_id);

        if (!$order) {
            return redirect()->route('user.account.orders')->with('error', 'Pesanan tidak ditemukan');
        }

        $orderItems = OrderItem::where('order_id', $order_id)->orderBy('id')->paginate(12);
        $transaction = Transaction::where('order_id', $order_id)->first();

        return view('user.order-details', compact('order', 'orderItems', 'transaction'));
    }

    public function account_cancel_order(Request $request)
    {
        $order = Order::find($request->order_id);
        $order->status = "canceled";
        $order->canceled_date = Carbon::now();
        $order->save();
        return back()->with("status", "Order has been cancelled successfully!");
    }

    // Menambahkan method baru untuk konfirmasi penerimaan pesanan
    public function account_confirm_delivery(Request $request)
    {
        // Validasi request
        $request->validate([
            'order_id' => 'required|exists:orders,id'
        ]);

        // Mengambil data order
        $order = Order::where('user_id', Auth::user()->id)->find($request->order_id);

        // Memeriksa apakah order ditemukan dan statusnya adalah 'delivered'
        if (!$order || $order->status !== 'delivered') {
            return back()->with('error', 'Tidak dapat mengonfirmasi penerimaan. Status pesanan harus "Diterima Admin".');
        }

        // Update status menjadi completed
        $order->status = 'completed';
        $order->completed_date = Carbon::now();
        $order->save();

        return back()->with('status', 'Pesanan berhasil dikonfirmasi telah diterima. Terima kasih!');
    }

    /**
     * Auto check payment status via AJAX (memanggil Midtrans API)
     */
    public function autoCheckPaymentStatus(Request $request)
    {
        $transaction = Transaction::where('id', $request->transaction_id)
            ->where('user_id', Auth::user()->id)
            ->first();

        if (!$transaction) {
            return response()->json(['error' => 'Transaction not found'], 404);
        }

        try {
            // Cek status di Midtrans API langsung
            \Midtrans\Config::$serverKey = config('midtrans.serverKey');
            \Midtrans\Config::$isProduction = config('midtrans.isProduction');

            $status = \Midtrans\Transaction::status($transaction->invoice);

            \Illuminate\Support\Facades\Log::info('Auto check - Midtrans status: ' . $status->transaction_status);

            // Update status berdasarkan response dari Midtrans
            if (in_array($status->transaction_status, ['capture', 'settlement'])) {
                $transaction->status = 'approved';
                $transaction->save();

                if ($transaction->order) {
                    $transaction->order->status = 'confirmed';
                    $transaction->order->confirmed_date = now();
                    $transaction->order->save();
                }

                return response()->json([
                    'status' => 'approved',
                    'message' => 'Payment confirmed'
                ]);
            } else {
                return response()->json([
                    'status' => $transaction->status,
                    'midtrans_status' => $status->transaction_status,
                    'message' => 'Payment still pending'
                ]);
            }
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error auto checking payment status: ' . $e->getMessage());
            return response()->json([
                'status' => $transaction->status,
                'error' => 'Failed to check payment status'
            ]);
        }
    }

    /**
     * Manual refresh status transaksi (untuk debugging)
     */
    public function manualRefreshStatus(Request $request)
    {
        $transaction = Transaction::where('id', $request->transaction_id)
            ->where('user_id', Auth::user()->id)
            ->first();

        if (!$transaction) {
            return redirect()->back()->with('error', 'Transaksi tidak ditemukan');
        }

        // Log current status
        \Illuminate\Support\Facades\Log::info('Manual refresh - Current status: ' . $transaction->status);

        // Cek di Midtrans API langsung
        try {
            \Midtrans\Config::$serverKey = config('midtrans.serverKey');
            \Midtrans\Config::$isProduction = config('midtrans.isProduction');

            $status = \Midtrans\Transaction::status($transaction->invoice);

            \Illuminate\Support\Facades\Log::info('Midtrans API Response: ', (array) $status);

            // Update status berdasarkan response dari Midtrans
            if (in_array($status->transaction_status, ['capture', 'settlement'])) {
                $transaction->status = 'approved';
                $transaction->save();

                if ($transaction->order) {
                    $transaction->order->status = 'confirmed';
                    $transaction->order->confirmed_date = now();
                    $transaction->order->save();
                }

                return redirect()->back()->with('success', 'Status berhasil diperbarui menjadi PAID');
            } else {
                return redirect()->back()->with('info', 'Status Midtrans: ' . $status->transaction_status);
            }
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error checking Midtrans status: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    /**
     * Check payment status untuk AJAX request
     */
    public function checkPaymentStatus($transaction_id)
    {
        $transaction = Transaction::where('id', $transaction_id)
            ->where('user_id', Auth::user()->id)
            ->first();

        if (!$transaction) {
            return response()->json(['error' => 'Transaction not found'], 404);
        }

        return response()->json([
            'status' => $transaction->status,
            'order_status' => $transaction->order ? $transaction->order->status : null
        ]);
    }

    // Halaman untuk menampilkan detail transaksi pembayaran
    public function order_payment($transaction_id)
    {
        $transaction = Transaction::where('id', $transaction_id)->first();
        $order = Order::find($transaction->order_id);
        $snaptoken = $transaction->snap_token;

        return view('order-payment', compact('transaction', 'order', 'snaptoken'));
    }

    // Load juga relasi 'penjadwalan'
    public function supplier_request()
    {
        $requests = SupplierRequest::where('user_id', Auth::user()->id)->latest()->get();
        $requests = SupplierRequest::with('penjadwalan')
            ->where('user_id', Auth::id())
            ->latest()
            ->paginate(3);      // ← berubah di sini

        return view('user.supplier.details', compact('requests'));
    }

    // Halaman alamat user - menampilkan semua alamat pengguna
    public function accountAddress()
    {
        $addresses = Address::where('user_id', Auth::id())->get();
        return view('user.address.account-address', compact('addresses'));
    }

    // Halaman tambah alamat user
    public function addAddress()
    {
        return view('user.address.add-address');
    }

    // Menyimpan alamat baru
    public function storeAddress(Request $request)
    {
        $request->validate([
            'name' => 'required|max:100',
            'phone' => 'required|numeric',
            'zip' => 'required',
            'state' => 'required',
            'city' => 'required',
            'address' => 'required',
            'locality' => 'required',
            'landmark' => 'required'
        ]);

        $address = new Address();
        $address->user_id = Auth::id();
        $address->name = $request->name;
        $address->phone = $request->phone;
        $address->zip = $request->zip;
        $address->state = $request->state;
        $address->city = $request->city;
        $address->address = $request->address;
        $address->locality = $request->locality;
        $address->landmark = $request->landmark;
        $address->country = $request->country ?? 'Indonesia';
        $address->type = $request->type ?? 'home';

        // Jika ini adalah alamat pertama atau user meminta set sebagai default
        $isFirstAddress = !Address::where('user_id', Auth::id())->exists();
        if ($isFirstAddress || $request->isdefault) {
            // Set semua alamat user menjadi non-default
            Address::where('user_id', Auth::id())->update(['isdefault' => false]);
            $address->isdefault = true;
        }

        $address->save();

        return redirect()->route('user.address.account-address')
            ->with('success', 'Alamat berhasil ditambahkan');
    }

    // Halaman edit alamat
    public function editAddress($id)
    {
        $address = Address::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        return view('user.address.edit-address', compact('address'));
    }

    // Update alamat
    public function updateAddress(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|max:100',
            'phone' => 'required|numeric',
            'zip' => 'required',
            'state' => 'required',
            'city' => 'required',
            'address' => 'required',
            'locality' => 'required',
            'landmark' => 'required'
        ]);

        $address = Address::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $address->name = $request->name;
        $address->phone = $request->phone;
        $address->zip = $request->zip;
        $address->state = $request->state;
        $address->city = $request->city;
        $address->address = $request->address;
        $address->locality = $request->locality;
        $address->landmark = $request->landmark;
        $address->country = $request->country ?? $address->country;
        $address->type = $request->type ?? $address->type;

        // Jika user meminta set sebagai default
        if ($request->isdefault) {
            // Set semua alamat user menjadi non-default
            Address::where('user_id', Auth::id())->update(['isdefault' => false]);
            $address->isdefault = true;
        }

        $address->save();

        return redirect()->route('user.address.account-address')
            ->with('success', 'Alamat berhasil diperbarui');
    }

    // Hapus alamat
    public function deleteAddress($id)
    {
        $address = Address::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $isDefault = $address->isdefault;

        $address->delete();

        // Jika alamat yang dihapus adalah default, set alamat lain sebagai default jika ada
        if ($isDefault) {
            $newDefault = Address::where('user_id', Auth::id())->first();
            if ($newDefault) {
                $newDefault->isdefault = true;
                $newDefault->save();
            }
        }

        return redirect()->route('user.address.account-address')
            ->with('success', 'Alamat berhasil dihapus');
    }

    // Set alamat sebagai default
    public function setDefaultAddress($id)
    {
        $address = Address::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        // Set semua alamat user menjadi non-default
        Address::where('user_id', Auth::id())->update(['isdefault' => false]);

        // Set alamat ini sebagai default
        $address->isdefault = true;
        $address->save();

        return redirect()->route('user.address.account-address')
            ->with('success', 'Alamat berhasil diatur sebagai default');
    }


    public function accountDetails()
    {
        $user = Auth::user();
        return view("user.accountdetails.account-details", compact('user'));
    }


    public function account_pending_order_details($pending_order_id)
    {
        $pendingOrder = PendingOrder::with(['items.product', 'transaction'])
            ->where('user_id', Auth::user()->id)
            ->findOrFail($pending_order_id);

        return view('user.pending-order-details', compact('pendingOrder'));
    }


    // Memperbarui detail akun pengguna
    public function updateAccountDetails(Request $request)
    {
        $user = Auth::user();

        // Validasi input dasar (nama, email, nomor HP, dan bio)
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'mobile' => [
                'required',
                'string',
                'min:10',
                'max:15',
                'unique:users,mobile,' . $user->id,
                'regex:/^(08|628)[0-9]{8,12}$/' // Format Indonesia
            ],
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'bio' => 'nullable|string|max:500',
            'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Validasi foto profil
            'profile_picture_action' => 'nullable|string|in:upload,delete',
        ], [
            'mobile.regex' => 'Format nomor HP tidak valid. Gunakan format 08xxxxxxxxxx atau 628xxxxxxxxxx',
            'mobile.unique' => 'Nomor HP sudah digunakan oleh pengguna lain',
            'email.unique' => 'Email sudah digunakan oleh pengguna lain',
            'profile_picture.image' => 'File harus berupa gambar',
            'profile_picture.mimes' => 'Format gambar harus: jpeg, png, jpg, atau gif',
            'profile_picture.max' => 'Ukuran gambar maksimal 2MB',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        try {
            DB::beginTransaction();

            // Handle foto profil
            $oldProfilePicture = $user->profile_picture;
            $newProfilePicture = $oldProfilePicture;

            // Jika ada aksi untuk foto profil
            if ($request->filled('profile_picture_action')) {
                $action = $request->profile_picture_action;

                if ($action === 'upload' && $request->hasFile('profile_picture')) {
                    // Upload foto profil baru
                    $file = $request->file('profile_picture');
                    $filename = time() . '_' . Str::random(6) . '.' . $file->getClientOriginalExtension();

                    // Pastikan folder ada
                    $uploadPath = public_path('uploads/foto_profile');
                    if (!file_exists($uploadPath)) {
                        mkdir($uploadPath, 0755, true);
                    }

                    // Pindahkan file ke folder uploads/foto_profile
                    $file->move($uploadPath, $filename);

                    // Path relatif untuk disimpan di database
                    $newProfilePicture = 'uploads/foto_profile/' . $filename;

                    // Hapus foto lama jika ada
                    if ($oldProfilePicture && file_exists(public_path($oldProfilePicture))) {
                        unlink(public_path($oldProfilePicture));
                    }
                } elseif ($action === 'delete') {
                    // Hapus foto profil
                    if ($oldProfilePicture && file_exists(public_path($oldProfilePicture))) {
                        unlink(public_path($oldProfilePicture));
                    }
                    $newProfilePicture = null;
                }
            }

            // Update informasi akun dasar
            $user->name = $request->name;
            $user->mobile = $request->mobile;
            $user->bio = $request->bio;
            $user->profile_picture = $newProfilePicture;

            // Cek apakah email berubah
            $emailChanged = $user->email !== $request->email;
            if ($emailChanged) {
                $user->email = $request->email;
                $user->email_verified_at = null; // Reset verifikasi email
            }

            // Periksa apakah semua field password diisi
            if ($request->filled('old_password') && $request->filled('new_password') && $request->filled('new_password_confirmation')) {
                // Validasi kata sandi
                $passwordValidator = Validator::make($request->all(), [
                    'old_password' => 'required|string',
                    'new_password' => [
                        'required',
                        'string',
                        'min:8',
                        'different:old_password',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()_+={}\[\]:;<>,.~\\\-]).{8,}$/'
                    ],
                    'new_password_confirmation' => 'required|same:new_password',
                ], [
                    'new_password.regex' => 'Kata sandi harus mengandung minimal 1 huruf kecil, 1 huruf besar, 1 angka, dan 1 simbol',
                    'new_password.different' => 'Kata sandi baru harus berbeda dengan kata sandi lama',
                    'new_password_confirmation.same' => 'Konfirmasi kata sandi tidak cocok',
                ]);

                if ($passwordValidator->fails()) {
                    return redirect()->back()
                        ->withErrors($passwordValidator)
                        ->withInput();
                }

                // Verifikasi kata sandi lama
                if (!Hash::check($request->old_password, $user->password)) {
                    return redirect()->back()
                        ->withErrors(['old_password' => 'Kata sandi lama tidak cocok'])
                        ->withInput();
                }

                // Perbarui kata sandi
                $user->password = Hash::make($request->new_password);
                $successMessage = 'Detail akun dan kata sandi berhasil diperbarui';
            } else {
                // Jika ada salah satu field password yang diisi tapi tidak lengkap
                if ($request->filled('old_password') || $request->filled('new_password') || $request->filled('new_password_confirmation')) {
                    return redirect()->back()
                        ->withErrors(['password_error' => 'Jika ingin mengubah kata sandi, semua field kata sandi harus diisi'])
                        ->withInput();
                }

                $successMessage = 'Detail akun berhasil diperbarui';
            }

            // Simpan perubahan
            $user->save();

            DB::commit();

            // Pesan sukses dengan informasi tambahan
            if ($emailChanged) {
                $successMessage .= '. Email Anda telah berubah dan memerlukan verifikasi ulang.';
            }

            if ($request->filled('profile_picture_action') && $request->profile_picture_action === 'upload') {
                $successMessage .= ' Foto profil berhasil diperbarui.';
            } elseif ($request->filled('profile_picture_action') && $request->profile_picture_action === 'delete') {
                $successMessage .= ' Foto profil berhasil dihapus.';
            }

            return redirect()->route('user.accountdetails.account-details')
                ->with('success', $successMessage);
        } catch (\Exception $e) {
            DB::rollback();

            // Jika ada file yang sudah diupload tapi gagal save, hapus file tersebut
            if (isset($newProfilePicture) && $newProfilePicture !== $oldProfilePicture && file_exists(public_path($newProfilePicture))) {
                unlink(public_path($newProfilePicture));
            }

            return redirect()->back()
                ->withErrors(['error' => 'Terjadi kesalahan: ' . $e->getMessage()])
                ->withInput();
        }
    }
}
